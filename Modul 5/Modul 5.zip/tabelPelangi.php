<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>tabel</title>
  </head>
  <body>
    <form  action="tabelEngine.php " method="post">
      <input type="text" name="baris" placeholder="baris">
      <input type="text" name="kolom" placeholder="kolom">
      <button type="submit" value="Klik">Klik</button>
    </form>

  </body>
</html>
